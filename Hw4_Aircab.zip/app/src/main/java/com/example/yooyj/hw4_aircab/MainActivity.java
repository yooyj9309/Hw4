package com.example.yooyj.hw4_aircab;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Aircab air = new Aircab(this);
        setContentView(air);
    }

}
