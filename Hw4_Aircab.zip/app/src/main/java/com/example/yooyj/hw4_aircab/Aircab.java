package com.example.yooyj.hw4_aircab;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * Created by yooyj on 2016-05-27.
 * This program is air cab pop game.
 *
 */

public class Aircab extends View {
    private Paint mPaint;
    private Bitmap cAircab;
    private Bitmap fAircab;
    float eventX, eventY;
    boolean control = true;
    boolean control2[][] = new boolean[8][12];

    public Aircab(Context c) {
        super(c);
        init();
    }
/*
* Setting no pop air cab and pop air cab image.
* And setting control2 array values true.
* */
    public void init() {
        mPaint = new Paint();
        Resources res = getResources();
        cAircab = BitmapFactory.decodeResource(res, R.drawable.aircab1);
        fAircab = BitmapFactory.decodeResource(res, R.drawable.aircab);
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 12; j++) {
                control2[i][j] = true;
            }
        }
    }

    public Aircab(Context c, AttributeSet a) {
        super(c, a);
        init();
    }
/*
* if control2 value is false, pop air cab image draws.
* Or not, no pop air cab image draws.
* */
    protected void onDraw(Canvas canvas) {
        for (int i = 0; i < 800; i = i + 100) {
            for (int j = 0; j < 1200; j = j + 100) {
                    canvas.drawBitmap(fAircab, i, j, mPaint);
               if(control2[i / 100][j / 100]==false) {
                    canvas.drawBitmap(cAircab, i-100, j-100, mPaint);
                }
            }
        }
    }
/*
* If event occurs, get x and y point value in point to occur event.
* And change the value (true -> false)
* */
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_UP) {
            eventX = event.getX();
            eventY = event.getY();
            Canvas canvas = new Canvas();

            for (int i = 0; i < 800; i = i + 100) {
                for (int j = 0; j < 1200; j = j + 100) {
                    if (eventX < i && eventX > i - 100 && eventY < j && eventY > j - 100) {
                        control2[i/100][j/100]=false;
                    }


                }
            }
            control = false;
        }

        invalidate();

        return true;
    }
}

