package com.example.yooyj.hw4_maze;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.Window;
import android.widget.Toast;
/*This Class makes miro using surfaceView.
Wall is drawn by view attribute and Path is drawn in surfaceView.
If you meet a wall, you go to first point.
And if you finish, you will see "finish" toast Message.
* */
public class MainActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new DrawingSurface(this));
    }

    public class DrawingSurface extends SurfaceView implements SurfaceHolder.Callback {
        Canvas cacheCanvas;
        Bitmap backBuffer, wall, point, player;
        int width, height, clientHeight;
        Paint paint;
        Context context;
        SurfaceHolder mHolder;
        PointWall p[][] = new PointWall[14][20];
        int pathOrWall[][];



        public DrawingSurface(Context context) {
            super(context);
            this.context = context;
            init();
        }

        public DrawingSurface(Context context, AttributeSet attrs) {
            super(context, attrs);
            this.context = context;
            init();
        }
/*
* Initialize miro & check whether this 2D array can be miro or not.
* And in While, if true, draw wall to have 1 in 2D array.
* Also, Each point value save is pointWall[][].
* */
        private void init() {
            mHolder = getHolder();
            mHolder.addCallback(this);
            wall = BitmapFactory.decodeResource(getResources(), R.drawable.wall);
            wall = Bitmap.createScaledBitmap(wall, 50, 50, false);
            point = BitmapFactory.decodeResource(getResources(), R.drawable.start);
            point = Bitmap.createScaledBitmap(point, 50, 50, false);
            player = BitmapFactory.decodeResource(getResources(), R.drawable.player);
            player = Bitmap.createScaledBitmap(player, 50, 50, false);
            pathOrWall = new int[14][20];
            Miro m;
            for (int i = 0; i < 14; i++)
                for (int j = 0; j < 20; j++) {
                    p[i][j] = new PointWall();
                    if (i == 0 || i == 13 || j == 0 || j == 19) {
                        pathOrWall[i][j] = 1;//벽
                    } else {
                        pathOrWall[i][j] = 0;//길
                    }
                }
            while (true) {
                makingMaze();
                m = new Miro(12, 18, pathOrWall);
                if (m.path()) {
                    break;
                }
            }
            pathOrWall[1][1]=0;
            pathOrWall[12][18]=1;
            savePoint();

            Log.d("dddd23", "result + " + m.path());

        }

        public void surfaceChanged(SurfaceHolder holder, int format, int width,
                                   int height) {
        }


        public void surfaceCreated(SurfaceHolder holder) {
            width = getWidth();
            height = getHeight();
            cacheCanvas = new Canvas();
            backBuffer = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888); //
            cacheCanvas.setBitmap(backBuffer);
            cacheCanvas.drawColor(Color.WHITE);

            paint = new Paint();
            paint.setColor(Color.RED);
            paint.setStrokeWidth(10);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setColor(Color.RED);

            draw();
        }

        public void surfaceDestroyed(SurfaceHolder holder) {
        }

        int lastX, lastY, currX, currY, charX=60, charY=150;
        boolean isDeleting, control = false;
        boolean allControl=false,Finish=false;
/*
* If you touch only a player(mario)'s point, you can make player move.
 * It is implemented in MotionEvent.ACTION_DOWN.
 * And if you meet wall, you can go to first point.
 * It is implemented in Action_move.
 * And in Action_UP, the character's points are saved.
* */
        @Override
        public boolean onTouchEvent(MotionEvent event) {
            boolean a = false;

            super.onTouchEvent(event);
            int action = event.getAction();

            switch (action & MotionEvent.ACTION_MASK) {
                case MotionEvent.ACTION_DOWN:
                    lastX = (int) event.getX();
                    lastY = (int) event.getY();
                    int xcor, ycor;
                    xcor = (charX - 50) / 50;
                    ycor = (charY - 160) / 50;
                    Log.d("aaaaa", " : " + lastX/50 + " : " +  charX/50 + " : " +  lastY/50 + " : " +  charY/50 + " : " +  xcor + " : " + ycor);
                    if (lastX/50 == charX/50 &&  charY/50==lastY/50 ) {

                        allControl=true;

                    }
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (isDeleting) break;

                    if(allControl) {
                        currX = (int) event.getX();
                        currY = (int) event.getY();


                        for (int i = 0; i < 14; i++) {
                            for (int j = 0; j < 20; j++) {
                                if (p[i][j].getX() <= currX && p[i][j].getX() >= currX - 50 && p[i][j].getY() <= currY && p[i][j].getY() >= currY - 50 && p[i][j].getPathOrWall() == 1) {

                                    charX = 50;
                                    charY = 160;
                                    control = false;
                                    isDeleting = true;
                                    a = true;
                                    break;
                                } else {
                                    control = true;
                                }
                            }
                            if (a)
                                break;
                        }

                        cacheCanvas.drawLine(lastX, lastY, currX, currY, paint);

                    }
                        lastX = currX;
                        lastY = currY;
                    if(currX>=610&&currX<=650&&currY<=1050&&currY>=1000) {
                        Toast.makeText(getApplicationContext(), "Finish", Toast.LENGTH_SHORT).show();
                        init();

                    }
                    break;
                case MotionEvent.ACTION_UP:

                    if (isDeleting) isDeleting = false;
                    cacheCanvas.drawColor(Color.WHITE);
                    if (control && allControl) {
                        charX = (int)event.getX();
                        charY = (int)event.getY();
                    } else {
                        cacheCanvas.drawBitmap(player, 60, 150, null);
                        isDeleting = false;
                    }
                    if (allControl)
                        allControl = false;

                    break;
                case MotionEvent.ACTION_POINTER_DOWN:
                    cacheCanvas.drawColor(Color.WHITE);
                    isDeleting = true;
                    break;
                case MotionEvent.ACTION_POINTER_UP:
                    break;
            }
            draw();
            return true;
        }
/*
*This method help to enable to draw in surfaceView.
* if control is false, the player will go to start point.
* else continuely go
* */

        protected void draw() {
            if (clientHeight == 0) {
                clientHeight = getClientHeight();
                height = clientHeight;
                backBuffer = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                cacheCanvas.setBitmap(backBuffer);
                cacheCanvas.drawColor(Color.WHITE);
            }
            drawPoint();
            if (!control)
                cacheCanvas.drawBitmap(player, 60, 150, null);
            else
                cacheCanvas.drawBitmap(player, (currX / 50) * 50 + 10, (currY / 50) * 50, null);


            Canvas canvas = null;
            try {
                canvas = mHolder.lockCanvas(null);
                paint.setColor(Color.CYAN);
                canvas.drawBitmap(backBuffer, 0, 0, paint);
            } catch (Exception ex) {
                ex.printStackTrace();
            } finally {
                if (mHolder != null) mHolder.unlockCanvasAndPost(canvas);
            }


        }
//Save each point(x,y) and information to check it is path or wall.
        public void savePoint() {
            for (int i = 10; i < 710; i += 50) {
                for (int j = 100; j < 1100; j += 50) {
                    int tmp1 = (i - 10) / 50;
                    int tmp2 = (j - 100) / 50;
                    if (pathOrWall[tmp1][tmp2] == 1) {
                        p[tmp1][tmp2].setX(i);
                        p[tmp1][tmp2].setY(j);
                        p[tmp1][tmp2].setPathOrWall(1);
                    } else {
                        p[tmp1][tmp2].setX(i);
                        p[tmp1][tmp2].setY(j);
                        p[tmp1][tmp2].setPathOrWall(0);
                    }
                }
            }
        }
/*
* Draw initial miro map.
* */
        public void drawPoint() {

            for (int i = 10; i < 710; i += 50) {
                for (int j = 100; j < 1100; j += 50) {
                    int tmp1 = (i - 10) / 50;
                    int tmp2 = (j - 100) / 50;

                    if (pathOrWall[tmp1][tmp2] == 1) {
                        cacheCanvas.drawBitmap(wall, i, j, null);
                    }
                }
            }
            paint.setColor(Color.CYAN);
            cacheCanvas.drawRect(60, 150, 110, 200, paint);

            cacheCanvas.drawRect(610, 1000, 660, 1050, paint);
        }
/*
* Using random function, decide the value (path or wall).
* */
        public void makingMaze() {
            for (int i = 0; i < 14; i++)
                for (int j = 0; j < 20; j++) {
                    int tmp = (int) (Math.random() * 2);
                    if (i == 0 || i == 13 || j == 0 || j == 19 || tmp == 0) {
                        pathOrWall[i][j] = 1;//벽
                    } else if (tmp == 1) {
                        pathOrWall[i][j] = 0;//길
                    }
                }
        }


        private int getClientHeight() {
            Rect rect = new Rect();
            Window window = ((Activity) context).getWindow();
            window.getDecorView().getWindowVisibleDisplayFrame(rect);
            int statusBarHeight = rect.top;
            int contentViewTop = window.findViewById(Window.ID_ANDROID_CONTENT).getTop();
            int titleBarHeight = contentViewTop - statusBarHeight;
            return ((Activity) context).getWindowManager().getDefaultDisplay().
                    getHeight() - statusBarHeight - titleBarHeight;
        }
    } // class DrawingSurface
}
/*Save information about x,y, and pathorWall.
* */
class PointWall {
    private int x;
    private int y;
    private int pathOrWall;


    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getPathOrWall() {
        return pathOrWall;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setPathOrWall(int pathOrWall) {
        this.pathOrWall = pathOrWall;
    }
}